import os
import cv2
import numpy as np
import time

subjects=["", "Gautam D Hariharan", "Robert Downey Jr."]

def detect_faces(f_cascade, colored_img, scaleFactor=1.1):
 img_copy=colored_img.copy()
 gray=cv2.cvtColor(img_copy, cv2.COLOR_BGR2GRAY)
 faces=f_cascade.detectMultiScale(gray, scaleFactor=scaleFactor, minNeighbors=5);
 print 'Faces found: ', len(faces)
 for(x,y,w,h) in faces:
  cv2.rectangle(img_copy, (x,y), (x+w,y+h), (0,255,0), 2)
 return img_copy

lbp_face_cascade=cv2.CascadeClassifier('/usr/share/opencv/lbpcascades/lbpcascade_frontalface.xml')
test2=cv2.imread('/home/gautam/Downloads/test pics/test7.jpg')
faces_detected_img=detect_faces(lbp_face_cascade, test2)
cv2.imshow('Test window', faces_detected_img)
cv2.waitKey(0)
cv2.destroyAllWindows()


dfpath="/home/gautam/Documents/facedetect/training-data"
def prepare_training_data(dfpath):
 dirs=os.listdir(dfpath)
 faces=[]
 labels=[]
 for dir_name in dirs:
  if not dir_name.startswith("s"):
   continue;

 label=int(dir_name.replace("s"," "))
 subject_dir_path=dfpath+"/"+dir_name
 subject_image_names=os.listdir(subject_dir_path)

 for image_name in subject_image_names:
  if image_name.startswith("."):
   continue;
 image_path=subject_dir_path+"/"+image_name
 image=cv2.imread(image_path)
 cv2.imshow("Training on image...", image)
 cv2.waitkey(100)

 face, rect=detect_face(image)
 if face is not None:
  faces.append(face)
  labels.append(label)

 cv2.destroyAllWindows()
 cv2.waitKey(1)
 cv2.destroyAllWindows()
 return faces, labels

print("Preparing data...")
faces, labels=prepare_training_data(dfpath)
print("Data prepared")
print("Total faces: ", len(faces))
print("Total labels: ", len(labels))
face_recognizer=cv2.face.createLBPHFaceRecognizer()
face_recognizer.train(faces, np.array(labels))

def draw_rectangle(img, rect):
 (x,y,w,h)=rect
 cv2.rectangle(img, (x,y),(x+w, y+h), (0,255,0), 2)

def draw_text(img, text, x, y):
 cv2.putText(img, text, (x,y), cv2.FONT_HERSHEY_PLAIN, 1.5, (0,255,0), 2)

def predict(test_img):
 img=test_img.copy()
 face, rect=detect_face(img)
 label=face_recognizer.predict(face)
 label_text=subjects[label]
 draw_rectangle(img, rect)
 draw_text(img, label_text, rect[0], rect[1]-5)
 return img

print("Predicting images...")
test_img1=cv2.imread("/home/gautam/Documents/facedetect/test-data/test1.jpg")
test_img2=cv2.imread("/home/gautam/Documents/facedetect/test-data/test2.jpg")

predicted_img1=predict(test_img1)
predicted_img2=predict(test_img2)
print("Prediction complete...")
cv2.imshow(subjects[1], predicted_img1)
cv2.imshow(subjects[2], predicted_img2)
cv2.waitKey(0)
cv2.destroyAllWindows()


























