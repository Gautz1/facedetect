import cv2
import time
def detect_faces(f_cascade, colored_img, scaleFactor=1.1):
 img_copy=colored_img.copy()
 gray=cv2.cvtColor(img_copy, cv2.COLOR_BGR2GRAY)
 faces=f_cascade.detectMultiScale(gray, scaleFactor=scaleFactor, minNeighbors=5);
 print 'Faces found: ', len(faces)
 for(x,y,w,h) in faces:
  cv2.rectangle(img_copy, (x,y), (x+w,y+h), (0,255,0), 2)
 return img_copy

haar_face_cascade=cv2.CascadeClassifier('/usr/share/opencv/haarcascades/haarcascade_frontalface_alt.xml')
test2=cv2.imread('/home/gautam/Downloads/test pics/test7.jpg')
faces_detected_img=detect_faces(haar_face_cascade, test2)
cv2.imshow('Test window', faces_detected_img)
cv2.waitKey(0)
cv2.destroyAllWindows()
